//
//  main.c
//  sortvst
//
//  Created by Богдан Rudkovskiy on 12.12.2024.
//


#include "sort.h"


int main(void) {
    int len, timer = 0;
    double *arr1 = NULL;
    printf("Enter lenght of array: ");
    scanf("%d", &len);
    if (len < 1 || len > MAX_LEN)
    {
        printf("Incorrent array length");
        return -1;
    }

    arr1 = (double *)malloc(len * sizeof(double));

    if (arr1 == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    one_array_generate(arr1, len);

    print_arr(arr1, len, "Unsorted array");

    timer -= clock();
    
    qsortRecursive(arr1, len);
    timer += clock();
    print_arr(arr1, len, "Processed array");
    if (sort_check(arr1, len) == 1) {
            printf("Required time for sorting is %lf seconds\n", (double)timer / CLOCKS_PER_SEC);
    }

    free(arr1);

    return 0;
}
