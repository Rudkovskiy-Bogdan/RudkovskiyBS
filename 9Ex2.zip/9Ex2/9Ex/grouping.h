#ifndef GROUPING
#define GROUPING

#include <stdio.h>
#include <math.h>

#define exp 1.e-6

void group(double * array, int length);
void printArray(double * array, int length);

#endif
