#ifndef TOOLS
#define TOOLS

#include <stdio.h>
#include <stdlib.h>

FILE * getFile(void);
double * getArray(FILE * file);

#endif
