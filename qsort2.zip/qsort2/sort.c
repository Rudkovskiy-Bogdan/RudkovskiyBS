//
//  main.c
//  sortvst
//
//  Created by Богдан Rudkovskiy on 12.12.2024.
//
#include "sort.h"

void print_arr(double *arr, int len, const char *str) {
    printf("\n%s:\n", str);
    if (len > MAX_PRINT_LEN) {
        for (int i = 0; i < MAX_PRINT_LEN; i++) {
            printf("%lf\n", arr[i]);
        } 
    } else {
        for (int i = 0; i < len; i++) {
            printf("%lf\n", arr[i]);
        }
    }
    
}

void one_array_generate(double *arr, int len) {
    double value;
    srand(time(NULL));
    for (int i = 0; i < len; i++) {
        value = ((rand() % (2 * MAX_ARRAY_VALUE + 1)) - MAX_ARRAY_VALUE) * RAND_MULTIPLIER;
        arr[i] = value;
    }
}





void qsortRecursive(double *arr, int len) {
    int i = 0;
    int j = len - 1;

    double mid = arr[len / 2];

    do {
        while(arr[i] - mid < -exp) {
            i++;
        }
        while(arr[j] - mid > exp) {
            j--;
        }

        if (i <= j) {
            double tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;

            i++;
            j--;
        }

    } while (i <= j);


    if(j > 0) {
        qsortRecursive(arr, j + 1);
    }
    if (i < len) {
        qsortRecursive(&arr[i], len - i);
    }

}
int sort_check(double * arr, int len)
{
    for (int i=0; i < len - 1; i++)
    {
        if (arr[i] > arr[i + 1]) return 0;
    }
    return 1;
}
int isSorted(double * array, int len) {
    for (int i = 0; i < len - 1; ++i) if (array[i] - array[i + 1] > exp) return 0;
    return 1;
}

