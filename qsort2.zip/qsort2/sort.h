#ifndef SORT
#define SORT

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEN 200000000
#define MAX_ARRAY_VALUE 1000000
#define RAND_MULTIPLIER 1e-2
#define exp 1.e-6
#define MAX_PRINT_LEN 10

void print_arr(double *arr, int len, const char *str);
void one_array_generate(double *arr, int len);
void qsortRecursive(double *arr, int len);
int isSorted(double * array, int len);
int sort_check(double * arr, int len);
#endif
