//
//  main.c
//  sortvst
//
//  Created by Богдан Rudkovskiy on 12.12.2024.
//
//#include <stdio.h>
//#include <stdlib.h>
//#include <time.h>
//
//#define MAX_LEN 20000000
//#define MAX_ARRAY_VALUE 10000
//#define RAND_MULTIPLIER 1e-2
//#define MAX_NUM_ITERATIONS 1000000
//#define DUMMY_SORT_CYCLE 1000
//#define MAX_PRINT_LEN 10
// 
//#include <math.h>
//#include <stdio.h>
//void print_arr(double * arr, int len, const char * str);
//void print_arr(double * arr, int len, const char * str)
//{
//    printf("\n%s:\n", str);
//    for (int i=0; i < len; i++) printf("arr[%d] = %.2lf\n", i, arr[i]);
//    printf("\n");
//}
//void two_arrays_generate(double * arr1, double *arr2, int len);
//void two_arrays_generate(double * arr1, double *arr2, int len)
//{
//    double value;
//    srand(time(NULL));
//    for (int i = 0; i < len; i++)
//    {
//        value = ((rand() % (2 * MAX_ARRAY_VALUE + 1)) - MAX_ARRAY_VALUE) * RAND_MULTIPLIER;
//        //value = rand();
//        arr1[i] = value;
//        arr2[i] = value;
//    }
//}
//void insertionSort(double arr1[], int N) {
//
//    // Starting from the second element
//    for (int i = 1; i < N; i++) {
//        double key = arr1[i];
//        int j = i - 1;
//
//        // Move elements of arr[0..i-1], that are
//          // greater than key, to one position to
//          // the right of their current position
//        while (j >= 0 && arr1[j] > key) {
//            arr1[j + 1] = arr1[j];
//            j = j - 1;
//        }
//
//        // Move the key to its correct position
//        arr1[j + 1] = key;
//    }
//}
//
//int main(void) {
//    double arr1;
//    int N = sizeof(arr1) / sizeof(arr1[0]);
//
//    printf("Unsorted array: ");
//    for (int i = 0; i < N; i++) {
//        printf("%lf ", arr1[i]);
//    }
//    printf("\n");
//
//    // Calling insertion sort on array arr
//    insertionSort(arr1, N);
//
//    printf("Sorted array: ");
//    for (int i = 0; i < N; i++) {
//        printf("%d ", arr1[i]);
//    }
//    printf("\n");
//
//    return 0;
//}


//Вот исправленный код:

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEN 20000000
#define MAX_ARRAY_VALUE 10000
#define RAND_MULTIPLIER 1e-2

void print_arr(double *arr, int len, const char *str);
void two_arrays_generate(double *arr, int len);
void insertionSort(double arr[], int N);

void print_arr(double *arr, int len, const char *str) {
    printf("\n%s:\n", str);
    for (int i = 0; i < len; i++)
        printf("arr[%d] = %.2lf\n", i, arr[i]);
    printf("\n");
}

void two_arrays_generate(double *arr, int len) {
    double value;
    srand(time(NULL));
    for (int i = 0; i < len; i++) {
        value = ((rand() % (2 * MAX_ARRAY_VALUE + 1)) - MAX_ARRAY_VALUE) * RAND_MULTIPLIER;
        arr[i] = value;
    }
}

void insertionSort(double arr[], int N) {
    for (int i = 1; i < N; i++) {
        double key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int main(void) {
    
    int N = 10; // Вы можете изменить количество элементов по необходимости
    double *arr1 = (double *)malloc(N * sizeof(double)); // Динамическое выделение памяти

    if (arr1 == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Генерация случайного массива
    two_arrays_generate(arr1, N);

    // Вывод не отсортированного массива
    print_arr(arr1, N, "Unsorted array");

    // Сортировка массива
    insertionSort(arr1, N);

    // Вывод отсортированного массива
    print_arr(arr1, N, "Sorted array");

    // Освобождение выделенной памяти
    free(arr1);
    
    return 0;
}
